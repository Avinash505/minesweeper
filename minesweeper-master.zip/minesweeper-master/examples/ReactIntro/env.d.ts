declare module '*.svg' {
  const src: string;
  export default src;
}
