export const add = (a: number, b: number): number => a + b;

export const mul = (a: number, b: number): number => a * b;
