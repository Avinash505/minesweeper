export { GameWithReactRedux } from './GameWithReactRedux';
