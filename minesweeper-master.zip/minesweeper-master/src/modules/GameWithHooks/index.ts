export { GameWithHooks } from './GameWithHooks';
