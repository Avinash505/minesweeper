export { MinesweeperWithReactRedux } from './MinesweeperWithReactRedux';
