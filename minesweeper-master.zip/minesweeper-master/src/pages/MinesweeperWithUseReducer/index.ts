export { MinesweeperWithUseReducer } from './MinesweeperWithUseReducer';
