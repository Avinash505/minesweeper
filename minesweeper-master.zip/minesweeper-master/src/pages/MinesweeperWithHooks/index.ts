export { MinesweeperWithHooks } from './MinesweeperWithHooks';
