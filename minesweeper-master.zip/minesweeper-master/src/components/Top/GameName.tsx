import styled from '@emotion/styled';

export const GameName = styled.h1`
  font-size: 2em;
`;
